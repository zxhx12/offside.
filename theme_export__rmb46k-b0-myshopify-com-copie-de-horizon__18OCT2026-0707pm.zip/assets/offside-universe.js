import { StandardEvents } from '@shopify/events';

class OffsideUniverse extends HTMLElement {
  connectedCallback() {
    this.abort?.abort();
    this.abort = new AbortController();
    const options = { signal: this.abort.signal };
    this.dialog = this.querySelector('dialog');
    this.detail = this.querySelector('[data-os-detail]');
    this.ropeObserver?.disconnect();
    this.ropeObserver = new ResizeObserver(() => this.positionRopes());
    this.ropeObserver.observe(this);
    this.querySelectorAll('.os-hanging-card__image').forEach(image => image.addEventListener('load', () => this.positionRopes(), options));
    this.positionRopes();
    this.reduced = matchMedia('(prefers-reduced-motion: reduce)');
    this.addEventListener('click', event => this.handleClick(event), options);
    this.addEventListener('change', event => this.selectVariant(event), options);
    this.dialog.addEventListener('cancel', event => { event.preventDefault(); this.close(); }, options);
    this.dialog.addEventListener('close', () => {
      this.source?.focus({ preventScroll: true });
      this.detail.replaceChildren();
      this.closing = false;
      this.dialog.classList.remove('is-closing');
    }, options);
    this.addEventListener(StandardEvents.cartLinesUpdate, event => {
      if (!this.dialog.open || !event.target.closest?.('product-form-component')) return;
      event.promise?.then(({ detail }) => {
        if (!detail?.didError && this.dialog.open) this.close();
      }).catch(() => {});
    }, options);
  }
  disconnectedCallback() { this.abort?.abort(); this.motion?.cancel(); this.ropeObserver?.disconnect(); }
  positionRopes() {
    const sceneTop = this.getBoundingClientRect().top;
    const cards = [...this.querySelectorAll('.os-hanging-card')];
    const firstRow = cards[0]?.getBoundingClientRect().top ?? sceneTop;
    cards.forEach(card => {
      const image = card.querySelector('.os-hanging-card__image');
      if (!image) return;
      const rect = card.getBoundingClientRect();
      const picture = image.getBoundingClientRect();
      const drawnHeight = image.naturalWidth ? Math.min(picture.height, picture.width * image.naturalHeight / image.naturalWidth) : picture.height;
      const hook = picture.top + (picture.height - drawnHeight) / 2 + drawnHeight * .12;
      const start = rect.top - firstRow < 100 ? sceneTop : rect.top - 18;
      card.style.setProperty('--rope-top', `${start - rect.top}px`);
      card.style.setProperty('--rope-length', `${Math.max(0, hook - start)}px`);
    });
  }
  handleClick(event) {
    const target = event.target.closest('a,button');
    if (target?.matches('[data-os-open]') && !event.ctrlKey && !event.metaKey && !event.shiftKey && event.button === 0) {
      const template = document.getElementById(target.dataset.osOpen);
      if (!template || !this.dialog.showModal) return;
      event.preventDefault();
      if (this.dialog.open) return;
      this.source = target;
      this.detail.replaceChildren(template.content.cloneNode(true));
      this.dialog.showModal();
      this.querySelector('[data-os-close]').focus({ preventScroll: true });
      const image = this.detail.querySelector('.os-detail__image');
      const initial = target.querySelector('img')?.getBoundingClientRect();
      const final = image?.getBoundingClientRect();
      if (image && initial?.width && final?.width && !this.reduced.matches) {
        const x = initial.x + initial.width / 2 - final.x - final.width / 2;
        const y = initial.y + initial.height / 2 - final.y - final.height / 2;
        this.motion = image.animate([
          { transform: `translate(${x}px,${y}px) scale(${initial.width / final.width})`, opacity: .7 },
          { transform: 'translate(0,0) scale(1)', opacity: 1 }
        ], { duration: 440, easing: 'cubic-bezier(.2,.7,.2,1)' });
        this.detail.querySelector('.os-detail__info').animate([{ opacity: 0 }, { opacity: 1 }], { duration: 380 });
      }
    } else if (target?.matches('[data-os-close]')) this.close();
    else if (target?.matches('[data-os-photo]')) {
      const image = this.detail.querySelector('.os-detail__image');
      image.removeAttribute('srcset');
      image.src = target.dataset.osPhoto;
      image.alt = target.dataset.alt;
      this.detail.querySelectorAll('[data-os-photo]').forEach(button => button.setAttribute('aria-pressed', String(button === target)));
    } else if (event.target === this.dialog) this.close();
  }
  selectVariant(event) {
    const input = event.target;
    if (!input.matches('[data-os-variant]')) return;
    const form = input.closest('form');
    form.querySelector('input[name="id"]').value = input.value;
    this.detail.querySelector('[data-os-price]').textContent = input.dataset.price;
    if (input.dataset.image) {
      const image = this.detail.querySelector('.os-detail__image');
      image.removeAttribute('srcset');
      image.src = input.dataset.image;
    }
  }
  async close() {
    if (!this.dialog.open || this.closing) return;
    this.closing = true;
    this.dialog.classList.add('is-closing');
    this.motion?.cancel();
    const image = this.detail.querySelector('.os-detail__image');
    const destination = this.source?.querySelector('img')?.getBoundingClientRect();
    const current = image?.getBoundingClientRect();
    if (image && destination?.width && current?.width && !this.reduced.matches) {
      const x = destination.x + destination.width / 2 - current.x - current.width / 2;
      const y = destination.y + destination.height / 2 - current.y - current.height / 2;
      this.motion = image.animate([{ transform: 'scale(1)', opacity: 1 }, { transform: `translate(${x}px,${y}px) scale(${destination.width/current.width})`, opacity: .3 }], { duration: 260, easing: 'ease-in', fill: 'forwards' });
      await this.motion.finished.catch(() => {});
    }
    this.dialog.close();
  }
}
if (!customElements.get('offside-universe')) customElements.define('offside-universe', OffsideUniverse);
